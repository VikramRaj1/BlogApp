
const express = require('express');
const mongoose = require('mongoose');
 const app = express();

 //bring in method override
const methodOverride = require('method-override');
 const blogRouter = require('./routes/blogs')
const Content = require('./models/content');


mongoose.connect('mongodb://localhost/blog',
{
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useFindAndModify:true,
})
.then(() => {
    console.log("DB Connected");
})
.catch((err) => {
    console.log("OH NO ERROR!!!");
    console.log(err);
});


app.set('view engine', 'ejs');

app.use(express.urlencoded({extended: false}));
app.use(methodOverride('_method'));

// app.get('/', (req, res) =>{
//     const blogs = [
//         {
//             title: 'The information we do not need',
//             snippet: 'You’ve probably heard of Lorem Ipsum before – it’s the most-used dummy text excerpt out there. People use it because it has a fairly',
//             author: 'Somtea Codes',
//             createdAt: new Date,
//             img: 'placeholder.jpg'

//         },
//         {

//             title: 'The information we do not need2',
//             snippet: 'You’ve probably heard of Lorem Ipsum before – it’s the most-used dummy text excerpt out there. People use it because it has a fairly',
//             author: 'Somtea Codes',
//             createdAt: new Date,
//             img: 'placeholder.jpg'
//         },
//         {
//             title: 'The information we do not need3',
//             snippet: 'You’ve probably heard of Lorem Ipsum before – it’s the most-used dummy text excerpt out there. People use it because it has a fairly',
//             author: 'Somtea Codes',
//             createdAt: new Date,
//             img: 'placeholder.jpg'
//         }
//     ]
//     res.render('index',{blogs: blogs})
// });
app.get('/',async(req, res)=>{
    let blogs = await Content.find().sort({timeCreated:'desc'});
    res.render('index',{blogs: blogs});
});

app.use(express.static("public"))

app.use('/blogs', blogRouter);


app.listen(3000, () => {
    console.log("Server running at port 3000");
})
